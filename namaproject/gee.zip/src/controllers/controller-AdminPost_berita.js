module.exports ={
    AdminPost_berita(req,res){
        res.render("AdminPost_berita",{
            url: 'http://localhost:5050/'
             });
        }
    }
